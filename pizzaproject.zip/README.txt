# Pizzakauppa – GitHub Automation Package

Tämä paketti sisältää:
- Valmiin GitHub Actions workflow'n
- Projektirakenteen
- Ohjeet käyttöönottoon

## Asennusohje
1. Pura ZIP.
2. Kopioi `.github`-kansio oman reposi juureen.
3. Aseta Project ID workflow-tiedostoon.
4. Push repositorioon.
5. Aja workflow GitHub Actions -sivulta.
